#!/usr/bin/env bash
set -e
cd "$(dirname "$0")/../bot"
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
if [ -f ../.env ]; then
  set -a
  . ../.env
  set +a
fi
python main.py
